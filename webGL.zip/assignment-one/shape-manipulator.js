var shapeManipulator = new function () {
	var triangle = [];
	var points = [];
	var lines = [];

	initTriangle = function () {
		// triangle = [
		// 		        vec2( 0, 0 ),
		// 		        vec2( -0.5,  0.5 ),
		// 		        vec2( -0.5, -0.5 )
		// 		   	];

		// triangle = [
		//    vec2(Math.sin(2.0 * Math.PI / 3.0 * 0), Math.cos(2.0 * Math.PI / 3.0 * 0)),
		//    vec2(Math.sin(2.0 * Math.PI / 3.0 * 1), Math.cos(2.0 * Math.PI / 3.0 * 1)),
		//    vec2(Math.sin(2.0 * Math.PI / 3.0 * 2), Math.cos(2.0 * Math.PI / 3.0 * 2))
		// ];
		triangle = [
		   [Math.sin(2.0 * Math.PI / 3.0 * 0), Math.cos(2.0 * Math.PI / 3.0 * 0)],
		   [Math.sin(2.0 * Math.PI / 3.0 * 1), Math.cos(2.0 * Math.PI / 3.0 * 1)],
		   [Math.sin(2.0 * Math.PI / 3.0 * 2), Math.cos(2.0 * Math.PI / 3.0 * 2)]
		];
	};

	tessellateTriangle = function (subdivisionCount, rotationAngle) {
		points = [];
		lines = [];
		divideTriangle( triangle, subdivisionCount, rotationAngle);
		return { points: points, lines: lines };
	};

	function divideTriangle( triangle, count, rotationAngle )
	{
		var a = triangle[0];
		var b = triangle[1];
		var c = triangle[2];

	    // check for end of recursion

	    if ( count == 0 ) {
	    	var aPrime = rotate(a, rotationAngle);
	    	var bPrime = rotate(b, rotationAngle);
	    	var cPrime = rotate(c, rotationAngle);
	    	
	    	points.push( aPrime, bPrime, cPrime );
	    	lines.push(aPrime, bPrime, bPrime, cPrime, cPrime, aPrime);
	        //triangle( a, b, c, rotationAngle );
	    }
	    else {

	        //bisect the sides

	        var ab = mix( a, b, 0.5 );
	        var ac = mix( a, c, 0.5 );
	        var bc = mix( b, c, 0.5 );

	        --count;

	        // four new triangles

	        divideTriangle( [a, ab, ac], count, rotationAngle );
	        divideTriangle( [c, ac, bc], count, rotationAngle );
	        divideTriangle( [b, bc, ab], count, rotationAngle );
	        divideTriangle( [ab, ac, bc], count, rotationAngle );
	    }
	}

	// function triangle( a, b, c, rotationAngle )
	// {
	//     points.push( rotate(a, rotationAngle), rotate(b, rotationAngle), rotate(c, rotationAngle) );
	// }

	function rotate(v, theta)
	{
	    var x = v[0];
	    var y = v[1];
	    //var d = Math.sqrt(x*x + y*y);
	    var d = Math.pow(Math.pow(x, 2) + Math.pow(y, 2), 0.5);

	    //theta * Math.PI/180
	    var rotationAngle = theta * d * 0.05;

	    var xPrime = x * Math.cos(rotationAngle) - y * Math.sin(rotationAngle);
	    var yPrime = x * Math.sin(rotationAngle) - y * Math.cos(rotationAngle);

	    return [xPrime, yPrime];
	}

	// function generatePolygonVertices(polygonVertexCount, boundingRadius){
 //      boundingRadius = boundingRadius || 0.3;
 //      var polygonVertices = new Array(polygonVertexCount); 

 //      var angleIncrement = 2.0 * Math.PI / polygonVertexCount;

 //      // generate the polygon outline
 //      for(var vIndex = 0; vIndex < polygonVertexCount; vIndex++){
 //        var x = boundingRadius * Math.cos(vIndex * angleIncrement);
 //        var y = boundingRadius * Math.sin(vIndex * angleIncrement);

 //        polygonVertices[vIndex] = [x, y]; 
 //      }

 //      return polygonVertices;
 //    }

 //    function generatePolygonTriangles(polygonVertices){

 //      var vertexCount = polygonVertices.length;
 //      var triangles = new Array(vertexCount);

 //      // break it into triangle subcomponents, which meet at poly's centroid (the origin)
 //      for(var tIndex = 0; tIndex < vertexCount; tIndex++)
 //      {
 //        var a = [0,0];
 //        var b = polygonVertices[tIndex];
 //        var c = polygonVertices[tIndex < vertexCount - 1 ? tIndex + 1 : 0]

 //          triangles[tIndex] = [a, b, c];
 //      }

 //      return triangles;
 //    }

 //    test = function (subdivisionCount, rotationAngle) {
 //    	points = [];
 //    	var initialTriangle = generatePolygonVertices(3);
 //    	var miniTriangles = generatePolygonTriangles(initialTriangle);
 //    	miniTriangles.forEach(function(triangle) {
 //    		divideTriangle(triangle[0], triangle[1], triangle[2], subdivisionCount, rotationAngle);
 //    	})
		
	// 	return points;
	// }; 


	return {
		initTriangle: initTriangle,
		tessellateTriangle: tessellateTriangle
		//test: test
	}
} ();